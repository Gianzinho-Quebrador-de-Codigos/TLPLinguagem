package com.fourcatsdev.aula17;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula17ApplicationTests {

	@Test
	void contextLoads() {
	}

}
